from typing import Final

MAX_MOVES_PENALTY:Final[int] = -100
MAX_MOVES_PER_TURN:Final[int] = 100
QUICK_DRAW_COUNT:Final[int] = 4
CUPS_PER_USER: Final[int] = 7
TOKENS_PER_CUP: Final[int] = 5
